USE encuentralo_db;
ALTER TABLE reports ADD COLUMN ai_embedding LONGTEXT NULL AFTER ai_confidence;
