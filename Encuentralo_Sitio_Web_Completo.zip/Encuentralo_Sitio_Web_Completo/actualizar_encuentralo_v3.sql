USE encuentralo_db;
ALTER TABLE reports ADD COLUMN image_hash VARCHAR(300) NULL AFTER ai_embedding;
