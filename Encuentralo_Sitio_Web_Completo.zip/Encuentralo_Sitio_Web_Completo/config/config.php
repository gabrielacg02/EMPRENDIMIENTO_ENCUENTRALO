<?php
const DB_HOST='localhost'; const DB_NAME='encuentralo_db'; const DB_USER='root'; const DB_PASS='';
const APP_NAME='Encuéntralo'; const BASE_URL='/Encuentralo_Sitio_Web_Completo';
const MAX_UPLOAD=5*1024*1024;
